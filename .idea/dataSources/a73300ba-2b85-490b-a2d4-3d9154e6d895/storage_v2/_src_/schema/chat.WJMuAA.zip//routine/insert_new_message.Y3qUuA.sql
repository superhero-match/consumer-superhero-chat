create
    definer = root@localhost procedure insert_new_message(IN id varchar(255), IN sender_id varchar(255),
                                                          IN receiver_id varchar(255), IN message varchar(255),
                                                          IN created_at varchar(255))
BEGIN

INSERT INTO message (
		message.id, 
		message.sender_id,
		message.receiver_id,
		message.message,
		message.created_at
	)
	VALUES (
		id, 
		sender_id,
		receiver_id,
		message,
		created_at
    );

END;

